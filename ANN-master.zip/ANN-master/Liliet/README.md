C++/ROOT codes 

This Folder includes:

- Class with the theoretical formulation of the DVCS cross-section.

  TBHDVCS.cxx        TBHDVCS.h

- Class with F1 and F2 definition.

  TFormFactors.cxx      TFormFactors.h
  
- Generated pseudo-data file with variance of F set to 5%.

   dvcs_xs_newsets_withCFFs.csv

-  Fitting of the pseudo data.

   Extraction/dvcs_xs_new_0.05.root (pseudo-data input file)
   
   Extraction/AnaBHDVCS.C  
